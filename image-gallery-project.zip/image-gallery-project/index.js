const path = require("path");
const express = require("express");
const multer = require("multer");
const fs = require("fs");

const app = express();
const PORT = 8000;

// Set up view engine and views directory
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

// Middleware to parse form data
app.use(express.urlencoded({ extended: false }));

// Serve static files from the "uploads" directory
app.use("/uploads", express.static(path.resolve("./uploads")));
app.use(express.static(path.join(__dirname, "public")));

// Route to render frontpage
app.get("/", (req, res) => {
  res.render("frontpage");
});

// Route to render login page
app.get("/login", (req, res) => {
  res.render("login");
});

// Route to handle login form submission
app.post("/login", (req, res) => {
  // Assuming authentication succeeds, redirect to homepage
  res.redirect("/homepage");
});

// Route to render registration page
app.get("/registration", (req, res) => {
  res.render("registration");
});


// Route to handle registration form submission
app.post("/registration", (req, res) => {
  // Handle registration logic here
  // This is where you would typically process form data, validate it, and store it in a database
  // For demonstration purposes, let's just redirect to the frontpage after registration
  res.redirect("/");
});

// Route to render homepage
app.get("/homepage", (req, res) => {
  res.render("homepage");
});

// Route to handle file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.resolve("./uploads")); // Use an absolute path
  },
  filename: function (req, file, cb) {
    cb(null, `${Date.now()}-${file.originalname}`); // Use backticks for template literals and Date.now() for current timestamp
  },
});

const upload = multer({ storage: storage });

app.post("/upload", upload.single("profileImage"), (req, res) => {
  // File upload successful
  res.render("logout"); // Render the logout page after uploading
});

// Route to handle logout and redirect to frontpage
app.post("/logout", (req, res) => {
  res.render("frontpage");
});

// Route to handle Continue button and redirect to homepage
app.post("/continue", (req, res) => {
  res.render("homepage");
});

// Route to render gallery page
app.get("/gallery", (req, res) => {
  const uploadsDir = path.resolve("./uploads");

  // Read the contents of the uploads directory
  fs.readdir(uploadsDir, (err, files) => {
    if (err) {
      console.error("Error reading directory:", err);
      return res.status(500).send("Error reading directory");
    }

    // Filter out non-image files
    const imageFiles = files.filter((file) => /\.(jpg|jpeg|png|gif)$/i.test(file));

    // Render the gallery page with the image file names
    res.render("gallery", { images: imageFiles });
  });
});

// Start the server
app.listen(PORT, () => console.log("Server started at PORT:", PORT));
